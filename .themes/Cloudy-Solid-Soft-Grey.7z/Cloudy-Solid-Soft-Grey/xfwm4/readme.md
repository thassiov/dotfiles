# Credits
Xfwm4 themes base on [Arc-Theme](https://github.com/horst3180/arc-theme) </br>
License : [GPLv3](https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Extract archive files in directory /.themes, /.local/share/themes or /usr/share/themes (as root)</b>
Have been test on : Debian 10 ( Xfce 12 ), 11 ( Xfce 4.16 )</br>

## Change themes
Xfce4 : Window Manager > Style </br>
