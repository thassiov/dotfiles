# Credits
This themes base on <b>Arc-Theme</b> </br>
Links : https://github.com/horst3180/arc-theme</br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Have been test on : Linux Mint 20 (Ulyana) Cinnamon Edition</br>
Install themes : Extract Archive File On Directory <i> /usr/share/themes (as root) or <i> /.themes</i> </br>

## Change themes
Linux Mint (Cinnamon): Menu > Settings > Themes > Windows Border </br>
